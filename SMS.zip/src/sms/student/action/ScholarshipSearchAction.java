package sms.student.action;

import java.util.ArrayList;
import java.util.Scanner;
import sms.student.controller.StudentController;
import sms.student.svc.ScholarshipSearchService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Scholarship;

public class ScholarshipSearchAction implements Action {
	
	ConsoleUtil consoleUtil = new ConsoleUtil();
	ScholarshipSearchService scholarshipSearchService = new ScholarshipSearchService();

	@Override
	public void execute(Scanner sc) throws Exception {
	
			
	}
	
}
