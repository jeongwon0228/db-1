package sms.student.action;

import java.util.Scanner;
import sms.student.svc.GradeModifyService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Grade;

public class GradeModifyAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	GradeModifyService gradeModifyService =	new GradeModifyService();

	@Override
	public void execute(Scanner sc) throws Exception {		
		
		
	}
	
}
