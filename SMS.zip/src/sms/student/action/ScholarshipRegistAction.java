package sms.student.action;

import java.util.Scanner;
import sms.student.svc.ScholarshipRegistService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Scholarship;

public class ScholarshipRegistAction implements Action {
	
	ConsoleUtil consoleUtil = new ConsoleUtil();
	ScholarshipRegistService scholarshipRegistService = new ScholarshipRegistService();

	@Override
	public void execute(Scanner sc) throws Exception {
		
		
	}
	
}
