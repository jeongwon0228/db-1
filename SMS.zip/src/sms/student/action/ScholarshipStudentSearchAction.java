package sms.student.action;

import java.util.ArrayList;
import java.util.Scanner;

import sms.student.svc.ScholarshipStudentSearchService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Scholarship;
import sms.student.vo.ScholarshipStudent;
import sms.student.vo.Grade;

public class ScholarshipStudentSearchAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	ScholarshipStudentSearchService scholarshipStudentSearchService = new ScholarshipStudentSearchService();

	
	@Override
	public void execute(Scanner sc) throws Exception {
				
		
	}
}
