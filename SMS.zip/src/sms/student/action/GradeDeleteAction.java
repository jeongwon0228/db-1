package sms.student.action;

import java.util.Scanner;
import sms.student.svc.GradeDeleteService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Grade;

public class GradeDeleteAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	GradeDeleteService gradeDeleteService = new GradeDeleteService();

	@Override
	public void execute(Scanner sc) throws Exception {

		
		
	}
	
}
