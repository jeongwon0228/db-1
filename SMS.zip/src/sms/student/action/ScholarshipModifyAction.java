package sms.student.action;

import java.util.Scanner;
import sms.student.svc.ScholarshipModifyService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Scholarship;

public class ScholarshipModifyAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	ScholarshipModifyService scholarshipModifyService = new ScholarshipModifyService();

	@Override
	public void execute(Scanner sc) throws Exception {
			
		
	}
	
}
