package sms.student.action;

import java.util.ArrayList;
import java.util.Scanner;
import sms.student.controller.StudentController;
import sms.student.svc.GradeSearchService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Grade;

public class GradeSearchAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	GradeSearchService gradeSearchService = new GradeSearchService();

	@Override
	public void execute(Scanner sc) throws Exception {

		
		
	}
	
}
