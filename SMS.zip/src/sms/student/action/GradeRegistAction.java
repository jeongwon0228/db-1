package sms.student.action;

import java.util.Scanner;
import sms.student.svc.GradeRegistService;
import sms.student.util.ConsoleUtil;
import sms.student.vo.Grade;
import sms.student.vo.Student;

public class GradeRegistAction implements Action {

	ConsoleUtil consoleUtil = new ConsoleUtil();
	GradeRegistService gradeRegistService = new GradeRegistService();

	@Override
	public void execute(Scanner sc) throws Exception {
		
		
		
	}
}
