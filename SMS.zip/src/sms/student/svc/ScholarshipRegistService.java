package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import sms.student.dao.ScholarshipDAO;
import sms.student.vo.Scholarship;

public class ScholarshipRegistService {

	public boolean searchScholarship(String sc_name) throws Exception{
		
		
		return false;
	}

	public boolean registScholarship(Scholarship newScholarship) throws Exception{

		return false;
	}
	
}
