package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import java.util.ArrayList;
import sms.student.dao.GradeDAO;
import sms.student.dao.ScholarshipDAO;
import sms.student.vo.Scholarship;
import sms.student.vo.ScholarshipStudent;
import sms.student.vo.Grade;

public class ScholarshipStudentSearchService {

	public Scholarship getSearchScholarship(String scholar_name) throws Exception{
		
		
		return null;
	}

	public ArrayList<Grade> getScoreListAddPercent() throws Exception{
		
		
		return null;
	}

	public ArrayList<ScholarshipStudent> getScholarshipStudentSearchList(
			Scholarship searchScholarship, ArrayList<Grade> gradeListAddPercent) throws Exception{

		
		return null;
	}
	
}
