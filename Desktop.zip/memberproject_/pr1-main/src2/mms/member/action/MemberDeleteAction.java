package mms.member.action;

import java.util.Scanner;

public class MemberDeleteAction implements Action{

	@Override
	public void execute(Scanner sc) throws Exception {
		return;
	}

}
