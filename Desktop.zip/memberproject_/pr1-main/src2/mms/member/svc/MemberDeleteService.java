package mms.member.svc;

import mms.member.vo.Member;

public class MemberDeleteService {
	
	public boolean deleteMember(Member newMember) throws Exception {
		
		return false;
	}
}
