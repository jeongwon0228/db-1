import sms.db.JdbcUtil;

public class JdbcMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JdbcUtil.getConnection();
	}

}
