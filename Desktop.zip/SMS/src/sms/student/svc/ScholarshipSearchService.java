package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import java.util.ArrayList;
import sms.student.dao.ScholarshipDAO;
import sms.student.vo.Scholarship;

public class ScholarshipSearchService {

	public ArrayList<Scholarship> getSearchScholarshipListBySc_name(String scholar_name) throws Exception{
		
		
		return null;
	}

	public ArrayList<Scholarship> getSearchScholarshipListByMoney(int scholar_money) throws Exception{
		
		
		return null;
	}

}
