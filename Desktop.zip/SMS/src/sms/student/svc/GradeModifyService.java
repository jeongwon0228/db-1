package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import sms.student.dao.GradeDAO;
import sms.student.vo.Grade;

public class GradeModifyService {

	public Grade getModifyGrade(int student_no) throws Exception{
		
		
		return null;
	}

	public boolean modifyGrade(Grade changeGrade) throws Exception{
		
		
		return false;
	}
}
