package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import sms.student.dao.GradeDAO;
import sms.student.vo.Grade;

public class GradeDeleteService {

	public Grade getDeleteScore(int student_no) throws Exception{
		
		
		return null;
	}
	
	public boolean deleteGrade(int student_no) throws Exception{
		
		
		return false;
	}
	
}
