package sms.student.svc;

import static sms.db.JdbcUtil.*;
import java.sql.Connection;
import sms.student.dao.GradeDAO;
import sms.student.dao.StudentDAO;
import sms.student.vo.Grade;
import sms.student.vo.Student;

public class GradeRegistService {
		
	public Student getRightStudent(int student_no) throws Exception{
		
		
		return null;
	}
	
	public boolean searchGrade(int student_no) throws Exception{
		
		
		return false;
	}
	
	public boolean registGrade(Grade newGrade) throws Exception{
		
		
		return false;
	}

}
