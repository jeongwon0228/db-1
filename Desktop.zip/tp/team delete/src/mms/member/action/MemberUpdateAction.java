package mms.member.action;

import java.util.Scanner;

public class MemberUpdateAction implements Action{

	@Override
	public void execute(Scanner sc) throws Exception {
		return;
		
	}

}
