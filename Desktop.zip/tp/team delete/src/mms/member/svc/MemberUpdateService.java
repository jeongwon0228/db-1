package mms.member.svc;

import mms.member.dao.MemberDAO;
import mms.member.vo.Member;

public class MemberUpdateService {
	
	public boolean updateMember(Member newMember) throws Exception {
		
		return false;
	}
}
